wp.customize.controlConstructor['kirki-radio'] = wp.customize.kirkiDynamicControl.extend({});
